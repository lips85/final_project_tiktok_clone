class DarkmodeConfigModel {
  bool isDarkMode;

  DarkmodeConfigModel({
    required this.isDarkMode,
  });
}
